<p align="center">
  <img src="https://i.ibb.co/Px7d60b/image.png" alt="Image">
</p>

MasonRootkit is a powerful tool written in C# that not only provides advanced rootkit functionalities but also offers a versatile UI for converting various file formats into executable formats like `.exe`, `.bat`, `.cmd`, `.com`, `.pif`, and `.scr`. This tool is designed for users who need to disguise their programs or scripts as different file types for various purposes.

## Features

- **File Format Conversion**: Easily convert files to `.exe`, `.bat`, `.cmd`, `.com`, `.pif`, or `.scr` formats using a simple and intuitive interface.
- **Rootkit Integration**: Select any file and convert it into a Rootkit, allowing for deep system integration and concealment.
- **Schtasks Integration**: A powerful feature similar to Startup, which automatically executes the program whenever the system restarts or shuts down and is restarted.
- **Connection Hiding**: Conceal the connections created by the program to ensure they remain undetectable.
- **Path Hiding**: MasonRootkit can hide its presence from its original file path to avoid detection.
- **Process Hiding**: The program remains invisible in the list of active processes.
- **Complete Concealment**: All aspects of the program are hidden to ensure it operates stealthily.

## Warning

**Important**: This program is intended for educational and experimental purposes only. Using this program for malicious or illegal activities is a violation of laws and ethics. We disclaim any responsibility for any misuse of this program. Any unlawful or unauthorized use of this program is the sole responsibility of the user.

## How to Use

1. Download and install the program on your device.
2. Follow the instructions provided for configuring and using the program as detailed in the accompanying documentation.
3. Use the file format conversion and rootkit features responsibly, ensuring all activities are legal and ethical.

---

<p align="center">
  <img src="https://i.ibb.co/JQydk3Z/Mason-Rootkit.png" alt="Image">
</p>

**Important Notice**: Use this program only for educational purposes. We do not take responsibility for any illegal or harmful use of the program.
